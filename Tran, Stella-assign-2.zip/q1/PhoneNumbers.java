package q1;

import java.text.DecimalFormat;
import java.util.Random;
/**
 * Class will randomly generate a phone number in the form 
 * XXX-XXX-XXXX with certain restrictions.
 *
 * @author Stella
 * @version 1.0
 */
public class PhoneNumbers {
    
    /** EIGHT represents 8.
     * To be used in random generator.
     * 
     */
    static final int EIGHT = 8;
    
    /**
     * TEN represents 10.
     * To be used in random generator.
     */
    static final int TEN = 10;
    
    /**
     * MIDDLE represents 636,
     * the max minium value for the middle of the phone number.
     * To be used in random generator.
     */
    static final int MIDDLE = 636;
    
    /** Drives the program.
     * 
     * @param args unused.
     */
    public static void main(String[] args) {
        Random gen = new Random();
        DecimalFormat dmt = new DecimalFormat("000");
        
        int digit1 = gen.nextInt(EIGHT);
        int digit2 = gen.nextInt(EIGHT);
        int digit3 = gen.nextInt(EIGHT);
        String digit456 = dmt.format(gen.nextInt(MIDDLE));
        int digit7 = gen.nextInt(TEN);
        int digit8 = gen.nextInt(TEN);
        int digit9 = gen.nextInt(TEN);
        int digit10 = gen.nextInt(TEN);
        
        System.out.println("Randomly generated phone number: " 
        + digit1 + digit2 + digit3 + "-" + digit456 + "-"
        + digit7 + digit8 + digit9 + digit10);
    }

};
