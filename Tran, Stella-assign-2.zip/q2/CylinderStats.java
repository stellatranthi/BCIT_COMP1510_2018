package q2;

import java.util.Scanner;
import java.text.DecimalFormat;
/**
 * Reads the radius and height of a cylinder and prints 
 * its surface area and volume to four decimal places.
 *
 * @author Stella
 * @version 1.0
 */
public class CylinderStats {
    /**
     * This is the main method (entry point) 
     * that gets called by the JVM.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        DecimalFormat fmt = new DecimalFormat("#.####");
        
        System.out.println("Please enter the cylinder's radius: ");
        double radius = scan.nextDouble();
        
        System.out.println("Please enter the cylinder's height: ");
        double height = scan.nextDouble();
        
        double surfaceArea = 2 * Math.PI * radius * (radius + height);
        double volume = Math.PI * Math.pow(radius, 2) * height;
        scan.close();
        System.out.println("Cylinder's surface area: " + fmt.format(surfaceArea)
                + "\nCylinder's volume: " + fmt.format(volume));
    }

};
