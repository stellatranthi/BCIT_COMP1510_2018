package q4;

/**
 *Takes in two different cylinder radius and height values.
 * Calculates surface area and height of both cylinders.
 *
 * @author Stella
 * @version 1.0
 */
public class Box {
    
    /** Height represents the box's height.
     * 
     */
    private double height;
    /** Width represents the box's width.
     * 
     */
    private double width;
    /** Depth represents the box's depth.
     * 
     */
    private double depth;
    /** Full represents whether the box is full or not.
     * 
     */
    private boolean full;
    
    /** Public constructor for object Box.
     * 
     * @param height for box.
     * @param width for box. 
     * @param depth for box.
     */
    public Box(double height, double width, double depth) {
        this.height = height;
        this.width = width;
        this.depth = depth;
        this.full = false;
    }
    
    /** Accessor for box's height.
     * 
     * @return box height. 
     */
    public double getHeight() {
        return height;
    }
    
    /** Modifier for box's height.
     * 
     * @param height for box.
     */
    public void setHeight(double height) {
        this.height = height;
    }
    
    /**Accessor for box's width.
     * 
     * @return width of box.
     */
    public double getWidth() {
        return width;
    }
    
    /**Modifier for box's width.
     * 
     * @param width for box.
     */
    public void setWidth(double width) {
        this.width = width;
    }
    
    /** Accessor for box's depth.
     * 
     * @return box's depth.
     */
    public double getDepth() {
        return depth;
    }
    
    /** Modifier for box's depth.
     * 
     * @param depth for box.
     */
    public void setDepth(double depth) {
        this.depth = depth;
    }
    
    /** Accessor to determine if box is full.
     * 
     * @return full or empty.
     */
    public boolean getFull() {
        return full;
    }
    
    /**Modifier to set the box to full or empty.
     * 
     * @param full *describes if box is full*
     */
    public void setFull(boolean full) {
        this.full = true;
    }
    
    /** Returns a one-line description of the box.
     * 
     * @return box description.
     */
    public String toString() {
        return "Box's height: " + this.getHeight() + "\tBox's width: "
                + this.getWidth() + "\tBox's depth: " + this.getDepth()
                + "\tIs box full? " + this.getFull();
    }
    
    
};
