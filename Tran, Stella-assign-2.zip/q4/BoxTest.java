package q4;

/**
 * Driver class to test out box class.
 *
 * @author Stella
 * @version 1.0
 */
public class BoxTest {
    /**THIRTY-SIX represents 36.
     * Used to test out box class.
     */
    public static final int THIRTY_SIX = 36;
    
    /**FORTY-EIGHT represents 48.
     * Used to test out box class.
     */
    public static final int FORTY_EIGHT = 48;
    
    /**
     * Drives the program.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        final Box box1 = new Box(12, 12, 12);
        final Box box2 = new Box(24, 24, 24);
        
        System.out.println("Box 1's original values (height, width, depth): " 
                + box1.getHeight() + " " + box1.getWidth() + " "
                + box1.getDepth() + " " + "\nIs the box full? " 
                + box1.getFull());
        
        box1.setHeight(THIRTY_SIX);
        box1.setWidth(THIRTY_SIX);
        box1.setDepth(THIRTY_SIX);
        box1.setFull(true);
        
        System.out.println("\nBox 2's original values (height, width, depth): " 
        + box2.getHeight() + " " + box2.getWidth() + " " 
        + box2.getDepth() + "\nIs the box full? " + box2.getFull());   
        
        box2.setHeight(FORTY_EIGHT);
        box2.setWidth(FORTY_EIGHT);
        box2.setDepth(FORTY_EIGHT);
        box2.setFull(true);
        
        System.out.println("\nBox 1: " + box1.toString()
                + "\nBox 2: " + box2.toString());
    }

};
