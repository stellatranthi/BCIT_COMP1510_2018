package q5;

import javafx.scene.layout.GridPane;
import javafx.scene.control.Button; 
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.text.Font;


/**
 * <p>This is where you put your description about what this class does. You
 * don't have to write an essay but you should describe exactly what it does.
 * Describing it will help you to understand the programming problem better.</p>
 *
 * @author Stella
 * @version 1.0
 */
public class EmailPane extends GridPane {
    
    /** MESSAGE_BOX represents the 150px for the message input.
     * 
     */
    static final int MESSAGE_BOX = 150;
    
    /** fontSize is set to twenty pixels.
     * 
     */
    static final int FONT_SIZE = 20;
    
    /**FOUR presents the fourth column.
     * 
     */
    static final int FOUR = 4;
    
    /**FIVE presents the fifth column.
     * 
     */
    static final int FIVE = 5;
    
    /**SIX presents the sixth column.
     * 
     */
    static final int SIX = 6;
    
    /**SEVEN presents the seventh column.
     * 
     */
    static final int SEVEN = 7;
    
    /**EIGHT presents the eighth column.
     * 
     */
    static final int EIGHT = 8;
    
    /**TEN presents the eighth column.
     * 
     */
    static final int TEN = 10;
    
    /** Input for "to: ".
     * 
     */
    private TextField toInput = new TextField();
    
    /** Input for "cc: ".
     * 
     */
    private TextField ccInput = new TextField();
    
    /** Input for "Bcc: ".
     * 
     */
    private TextField bccInput = new TextField();
    
    /** Input for "subject: ".
     * 
     */
    private TextField subjectInput = new TextField();
    
    /** Input for message.
     * 
     */
    private TextArea messageInput = new TextArea();
    
    /** Sets the font size to 20.
     * 
     */
    private Font font = new Font(FONT_SIZE);
    
    /** Contains Labels, TextFields and TextArea for composing an email.
     * 
     */
    public EmailPane() {
    Label to = new Label("To:");
    to.setFont(font);
    Label cc = new Label("CC:");
    cc.setFont(font);
    Label bcc = new Label("Bcc:");
    bcc.setFont(font);
    Label subject = new Label("Subject:");
    subject.setFont(font);
    
    messageInput.setMinSize(MESSAGE_BOX, MESSAGE_BOX);
    
    Button send = new Button("Send");
    send.setOnAction(this::composeEmail);

    add(to, 0, FOUR); 
    add(toInput, SIX, FOUR); 
    add(cc, 0, FIVE); 
    add(ccInput, SIX, FIVE);
    add(bcc, 0, SIX); 
    add(bccInput, SIX, SIX);
    add(subject, 0, SEVEN); 
    add(subjectInput, SIX, SEVEN); 
    add(messageInput, SIX, EIGHT); 
    add(send, 0, TEN);
        
    }
   
    /** Prints out all user-printed information
     * and clears the input fields.
     * 
     * @param event for 
     */
    public void composeEmail(ActionEvent event) {
        System.out.println("To: " + toInput.getText()
                + "\nCC: " + ccInput.getText()
                + "\nBcc: " + bccInput.getText()
                + "\nSubject: " + subjectInput.getText()
                + "\nMessage: " + messageInput.getText());
        
        toInput.setText("");
        ccInput.setText("");
        bccInput.setText("");
        subjectInput.setText("");
        messageInput.setText("");
    }
    
}

