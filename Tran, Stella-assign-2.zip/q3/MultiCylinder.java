package q3;

import java.util.Scanner;
/**
 * Takes in two different cylinder radius and height values.
 * Calculates surface area and height of both cylinders.
 *
 * @author Stella
 * @version 1.0
 */
public class MultiCylinder {
    /**
     * <p>This is the main method (entry point) that gets called by the JVM.</p>
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter your cylinder's original radius: ");
        double radius = scan.nextDouble();
        System.out.println("Please enter your cylinder's original height: ");
        double height = scan.nextDouble();
        final Cylinder c1 = new Cylinder(radius, height);
        System.out.println("Please enter your cylinder's new radius: ");
        double radius2 = scan.nextDouble();
        System.out.println("Please enter your cylinder's new height: ");
        double height2 = scan.nextDouble();
        final Cylinder c2 = new Cylinder(radius2, height2);
        
        System.out.println("Cylinder's original radius: " + c1.getRadius()
        + "\tCylinder's original height: " + c1.getHeight());
        
        System.out.println("Cylinder's new radius" + c2.getRadius()
        + "\tCylinder's new height: " + c2.getHeight());
        
        System.out.println("\nCylinder's surface area with original values: " 
                + c1.getSurfaceArea() 
                + "\nCylinder's volume with original values: " 
                + c1.getVolume());
        
        System.out.println("\nCylinder's surface area with new values: " 
                + c2.getSurfaceArea()
                + "\nCylinder's volume with new values: " 
                + c2.getVolume());
        scan.close();
    }

};
