package q3;

/**
 * <p>Class contains instance data that will represent a
 * cylinder's radius and height. <p>
 * 
 * 
 * <p>Methods will be avaliable for accessing and 
 * modifiying the cylinder's properties.<p>
 * 
 * <p>Class will also calculate and return cylinder's volume
 * and surface area.<p>
 *
 * @author Stella
 * @version 1.0
 */
public class Cylinder {
    /** Represents the cylinder's radius.
     * 
     */
    private double radius;
    
    /** Represents the cylinder's height.
     * 
     */
    private double height;
    
    /**Constructor for the class Cylinder.
     * 
     * @param radius *Cylinder's radius*
     * @param height *Cylinder's height*
     */
    public Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    
    /**Accessor for cylinder's radius.
     * 
     * @return value of radius.
     */
    public double getRadius() {
        return radius;
    } 
    
    /** Modifier for cylinder's radius.
     * 
     * @param radius for cylinder.
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    /**Accessor for cylinder's height.
     * 
     * @return cylinder's height.
     */
    public double getHeight() {
        return height;
    }
    
    /** Modifier for cylinder's height.
     * 
     * @param height for cylinder.
     */
    public void setHeight(double height) {
        this.height = height;
    }
    
    /**Calculates and returns the cylinder's surface area.
     * 
     * @return cylinder's surface area.
     */
    public double getSurfaceArea() {
        return (2 * Math.PI * (radius + height));
    }
    
    /**Calculates and returns the cylinder's volume.
     * 
     * @return cylinder's volume.
     */
    public double getVolume() {
    return (Math.PI * Math.pow(radius, 2) * height);
    }
    
    /**Returns a String representation of the 
     * surface area and volume.
     * 
     * @return surface area and volume values.
     * 
     */
    public String toString() {
        return ("Cylinder's surface area: " 
        + this.getSurfaceArea() + "\tCylinder's volume"
        + this.getVolume());
    }
};
