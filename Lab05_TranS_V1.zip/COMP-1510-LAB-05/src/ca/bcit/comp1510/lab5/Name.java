/**
 * 
 */
package ca.bcit.comp1510.lab5;

/** Will be used to present a Name concept. 
 * @author stella
 * @version 1
 */
public class Name {
    /**
     * string represents the first name.
     */
    private String firstName;
    /**
     *  string represents the middle name.
     */
    private String middleName;
    /**
     * string represents the last name.
     */
    private String lastName;
    
    /** Constructor for class Name.
     * 
     * @param firstName unused
     * @param middleName unused
     * @param lastName unused
     */
    public Name(String firstName, String middleName, String lastName) {
       this.firstName = firstName;
       this.middleName = middleName;
       this.lastName = lastName;
    }
    
    /** method to get first name. 
     * 
     * @return to firstName description. 
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Modifier for first name.  
     * @param firstName unused
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    /** Accessor to get middle name. 
     * 
     * @return middleName description.
     */
    public String getMiddleName() {
        return middleName;
    }
    
    /** Modifier for middle name.
     * 
     * @param middleName unused
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    /** Accessor to get last name. 
     * 
     * @return last name description.
     */
    public String getLastName() {
        return lastName;
    }
    
    /** Modifier for last name.
     * 
     * @param lastName unused
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    /**Accessor to get the length of the full name.
     * 
     * @return length of full name.
     */
    public int getFullLength() {
        String fullName = firstName + middleName + lastName;
        return fullName.length();
    }
    /**Accessor to get the initials of name in uppercase.
     * 
     * @return three initials in uppercase.
     */
    public String getInitals() {
        String firstNameCharCap = firstName.substring(0, 1);
        String middleNameCharCap = middleName.substring(0, 1);
        String lastNameCharCap = lastName.substring(0, 1);
        return firstNameCharCap.toUpperCase() + ". "
            + middleNameCharCap.toUpperCase() + ". "
            + lastNameCharCap.toUpperCase() + ". ";
    }
    
    /**Accessor to get the letter 
     * at the user-inputted integer.
     * 
     * @param n *to hold user-inputted integer*
     * that does not exceed name length.
     * 
     * @return character at the user-inputted integer.
     */
    public char getNthChar(int n) {
        String fullName = firstName + middleName + lastName;
        fullName = fullName.trim();
        return fullName.charAt(n - 1);
    }
    /**Accessor to get name in the order: last, first, middle.
     * 
     * @return last name followed by first name 
     * then middle name.
     */
    public String getLastNameFirst() {
        return (lastName + ", " + firstName + " " + middleName);
    }
    /**Accessor to check if first name equals user-input.
     * 
     * @param input *user-inputed first name(
     * @return true if first name equals user-input.
     */
    public Boolean equalsFirstName(String input) {
        return firstName.equalsIgnoreCase(input);
    }
    /**Accessor to check if full name equals user-input.
     * 
     * @param nameInput *user-input full name*
     * @return true if full name equals user-input.
     */
    public Boolean equalsName(Name nameInput) {
        String newName = nameInput.toString();
        return this.toString().equalsIgnoreCase(newName);
    }
    /**
     * Returns a String representation of the full name.
     * @return toString description
     */
    public String toString() {
        String fullName = firstName + " " + middleName + " " + lastName;
        return fullName;
    }

}
