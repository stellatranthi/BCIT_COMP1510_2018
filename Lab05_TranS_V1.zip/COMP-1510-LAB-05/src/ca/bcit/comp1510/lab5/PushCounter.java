/** Program that emulates Push counter and input field.
 * 
 */
package ca.bcit.comp1510.lab5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

/**
 * Demonstrates JavaFX buttons and event handlers.
 * 
 * @author Lewis & Loftus 9e
 * @author BCIT
 * @version 2017
 */
public class PushCounter extends Application {
    /** Font size is set to 18.
     * 
     */
    public static final double FONT = 18;
    
    /** Field width set to 50.
     * 
     */
    public static final double FIELD_WIDTH = 50;
    
    /** Holds the number of time the button is pressed. */
    private int count;
    
    /** Holds the number of time the button is pressed. */
    private int count2;
    
    /** Displays the number of times the button is pressed. */
    private Text countText;
    
    /** Displays the number of times the button is pressed. */
    private Text countText2;
    
    /** Holds a string representing a number of button pushes. */
    private TextField pushes;
    
    /**
     * Presents a GUI containing a button and text that displays
     * how many times the button is pushed.
     * @param primaryStage a Stage
     */
    public void start(Stage primaryStage) {     
        
        count = 0;
        countText = new Text("Pushes: 0");
        
        count2 = 0;
        countText2 = new Text("Pushes: 0");
        
        Button yes = new Button("Yes++");
        yes.setOnAction(this::processButtonPress); // Wow!
        
        Button yesMinus = new Button("Yes-");
        yesMinus.setOnAction(this::processButtonPress2); // Wow!
        
        Button no = new Button("No++");
        no.setOnAction(this::processButtonPress3); // Wow!
        
        Button noMinus = new Button("No--");
        noMinus.setOnAction(this::processButtonPress4); // Wow!
        
        Font font = new Font(FONT);
        
        pushes = new TextField();
        pushes.setFont(font);
        pushes.setPrefWidth(FIELD_WIDTH);
        pushes.setAlignment(Pos.CENTER);
        pushes.setOnAction(this::processReturn); // Wow!
        
        FlowPane pane = new FlowPane(countText, yes, yesMinus, no, 
                noMinus, countText2, pushes);
        pane.setAlignment(Pos.CENTER);
        
        final int horizontalGap = 20;
        pane.setHgap(horizontalGap);
        pane.setStyle("-fx-background-color: cyan");

        final int appWidth = 600;
        final int appHeight = 100;
        Scene scene = new Scene(pane, appWidth, appHeight);

        primaryStage.setTitle("Push Counter");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPress(ActionEvent event) {
        count++;
        countText.setText("Pushes: " + count);
    }
    
    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPress2(ActionEvent event) {
        count--;
        countText.setText("Pushes: " + count);
    }
    
    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPress3(ActionEvent event) {
        count2++;
        countText2.setText("Pushes: " + count2);
    }
    
    /**
     * Updates the counter and text when the button is pushed.
     * @param event invokes this method
     */
    public void processButtonPress4(ActionEvent event) {
        count2--;
        countText2.setText("Pushes: " + count2);
    }
    
    /**
     * Changes the number of pushes to what the user inputted.
     * 
     * @param event
     *            invokes this method
     */
    public void processReturn(ActionEvent event) {
        count = Integer.parseInt(pushes.getText());
        count2 = Integer.parseInt(pushes.getText());
        
        countText.setText("Pushes: " + count);
        countText2.setText("Pushies: " + count2);
        pushes.setText("");
    }
 

    /**
     * Launches the JavaFX application.
     * 
     * @param args
     *            command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}   
