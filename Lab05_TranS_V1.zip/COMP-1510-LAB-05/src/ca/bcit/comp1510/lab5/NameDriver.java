/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**Drives the Name class.
 * 
 * @author stella
 * @version 1
 */
public class NameDriver {
    /** Three represents 3.
     * Will be used to test out NameDriver.
     */
    public static final int THREE = 3;
    /**Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        final Name myName = new Name("Stella", "Thi", "Tran");
        final Name trialName = new Name("Stella", "Thi", "Tran");
        System.out.println("Length of name: " + myName.getFullLength());
        System.out.println("Initials: " + myName.getInitals());
        System.out.println("Character at user-inputted integer: " 
                + myName.getNthChar(THREE));
        System.out.println("Last name first format: " 
                + myName.getLastNameFirst());
        System.out.println("User-input matches first name: " 
                + myName.equalsFirstName("Stella"));
        System.out.println("User-input matches full name: " 
                + myName.equalsName((trialName)));
        System.out.println("Full name printed: " + myName.toString());
    }

}
