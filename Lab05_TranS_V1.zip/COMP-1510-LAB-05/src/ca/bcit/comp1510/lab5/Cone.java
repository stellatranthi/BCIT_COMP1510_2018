/**
 * 
 */
package ca.bcit.comp1510.lab5;

/** Calculates a cone's volume, slant height, and surface area.
 * @author stella
 * @version 1
 */
public class Cone {
    
    /** ONE_THIRD represents (1 / 3).
     * Will be used in volume calculation. 
     * 
     */
    public static final double THREE = 3.0;    
    /** radius represents the cone's radius.
     * 
     */
    private double radius;
    /** height represents the cone's height.
     * 
     */
    private double height;
    
    /** Constructor for Cone Class.
     * 
     * @param radius **Cone's radius**
     * @param height **Cone's height**
     */
    public Cone(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    
    /**Accessor for radius.
     * 
     * @return radius.
     */
    public double getRadius() {
        return radius;
    }
    /** Modifier for radius.
     * 
     * @param radius **To set cone's radius**
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    /**Accessor for height.
     * 
     * @return height.
     */
    public double getHeight() {
        return height;
    }
    /** Modifier for height.
     * 
     * @param height **To set cone's height**
     */
    public void setHeight(double height) {
        this.height = height;
    }
    
    /**Volume calculation.
     * 
     * @return cone's volume.
     */
    public double getVolume() {
        return ((1 / THREE) * Math.PI * Math.pow(radius, 2) * height);
    }
    /** Slant height calculation.
     * 
     * @return cone's slant height.
     */
    public double getSlantHeight() {
        return Math.sqrt((Math.pow(radius, 2) + (Math.pow(height, 2))));
    }
    /** Surface area calculation.
     * 
     * @return cone's surface area.
     */
    public double getSurfaceArea() {
        return Math.PI * Math.pow(radius, 2) + Math.PI * radius 
                * (Math.sqrt(Math.pow(radius, 2) + Math.pow(height, 2)));
    }
    /** Converts cone's volume, slant height, and surface area
     * to String.
     * 
     * @return cone's volume, slant height, and surface area.
     */
    public String toString() {
        return "Volume: " + this.getVolume() + "\nSlant Height: " 
                + this.getSlantHeight() + "\nSurface Area: " 
                + this.getSurfaceArea();
    }
}

