/**
 * 
 */
package ca.bcit.comp1510.lab5;

/** Will calculate and return the surface area of a sphere.
 * @author stella
 * @version 1
 */
public class Sphere {
    /** THREE represents 3.
     *  The '3' will be used in calculating sphere surface area.
     * 
     */
    private static final int THREE = 3;
    /** FOUR represents 4.
     *  The '4' will be used in calculating sphere surface area.
     * 
     */
    private static final int FOUR = 4;

    
    /** radius represents the radius of the sphere.
     * 
     */
    private double radius;
    /** valueX represents the X-coordinate.
     * 
     */
    private double valueX;
    /** valueY represents the Y-coordinate.
     * 
     */
    private double valueY;
    /** valueZ represents the Z-coordinate.
     * 
     */
    private double valueZ;
    
    
    
    
    /** Constructor for sphere class.
     * 
     * @param radius unused
     * @param valueX unused
     * @param valueY unused
     * @param valueZ unused
     */
    public Sphere(double radius, double valueX, double valueY, double valueZ) {
        this.radius = radius;
        this.valueX = valueX;
        this.valueY = valueY;
        this.valueZ = valueZ;
    }
    
    /**Accessor for x-coordinate.
     * 
     * @return valueX.
     */
    public double getvalueX() {
        return valueX;
    }
    /** Modifier for x-coordinate.
     * 
     * @param valueX unused.
     */
    public void setValueX(double valueX) {
        this.valueX = valueX;
    }
    
    /** Accessor for y-coordinate.
     * 
     * @return valueY.
     */
    public double getValueY() {
        return valueY;
    }
    
    /** Modifier for y-coordinate.
     * 
     * @param valueY unused
     */
    public void setValueY(double valueY) {
        this.valueY = valueY;
    }
    
    /**Accessor for z-coordinate.
     * 
     * @return valueZ description.
     */
    public double getValueZ() {
        return valueZ;
    }
    /** Modifier for z-coordinate.
     * 
     * @param valueZ unused
     */
    public void setValueZ(double valueZ) {
        this.valueZ = valueZ;
    }
    
    /** Accessor to get radius.
     * 
     * @return radius description.
     */
    public double getRadius() {
        return radius;
    }
    /** Modifier for radius. 
     * 
     * @param radius unused.
     */
    public void setRadius(double radius) {
        this.radius = radius;
    }
    
    /** Volume calculation. 
     * 
     * @return volume.
     */
    public double getVolume() {
        return (FOUR * Math.PI * Math.pow(radius, THREE) / THREE);
    }
    
    /** Surface area calculation. 
     * 
     * @return surface area. 
     */
    public double getSurfaceArea() {
        return (FOUR * Math.PI * Math.pow(radius, 2));
        
    }

        /** Returns a String representation of the surface area.
         * 
         * @return surface area and volume description.
         * 
         */
        public String toString() {
            String result = "Surface Area: " + this.getSurfaceArea() 
            + "\nVolume: " + this.getVolume();
            return result;
        }
}
