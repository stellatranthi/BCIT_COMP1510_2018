/**
 * 
 */
package ca.bcit.comp1510.lab5;

/** Calculates surface area, volume, face diagonal, and space diagonal. 
 * @author Stella
 * @version 1
 */
public class Cube {
    /** SIX represents the number 6
     * that will be used in surface area calculations.
     * 
     */
    public static final int SIX = 6;
    
    /** THREE represents the number 3
     * that will be used in surface area calculations.
     * 
     */
    public static final int THREE = 3;
    
    /** valueX represents the X-coordinate.
     * 
     */
    private double valueX;
    /** valueY represents the Y-coordinate.
     * 
     */
    private double valueY;
    /** valueZ represents the Z-coordinate.
     * 
     */
    private double valueZ;
    /** edgeLength represents the cube's edge length.
     * 
     */
    private double edgeLength;
    
    /** Constructor for class Cube.
     * 
     * @param valueX *x-coordinate*
     * @param valueY *y-coordinate*
     * @param valueZ *z-coordinate*
     * @param edgeLength *edge length of cube*
     */
    public Cube(double valueX, double valueY, double valueZ, 
            double edgeLength) {
        this.valueX = valueX;
        this.valueY = valueY;
        this.valueZ = valueZ;
        this.edgeLength = edgeLength;
    }
    
    /**Accessor for x-coordinate.
     * 
     * @return valueX.
     */
    public double getValueX() {
        return valueX;
    }
    /** Modifier for x-coordinate.
     * 
     * @param valueX *new x-coordinate*
     */
    public void setValueX(double valueX) {
        this.valueX = valueX;
    }
    /** Accessor for y-coordinate.
     * 
     * @return y-coordinate.
     */
    public double getValueY() {
        return valueY;
    }
    
    /** Modifier for y-coordinate.
     * 
     * @param valueY * new y-coordinate*
     */
    public void setValueY(double valueY) {
        this.valueY = valueY;
    }
    
    /**Accessor for z-coordinate.
     * 
     * @return z-coordinate. 
     */
    public double getValueZ() {
        return valueZ;
    }
    /** Modifier for z-coordinate.
     * 
     * @param valueZ * new z-coordinate*
     */
    public void setValueZ(double valueZ) {
        this.valueZ = valueZ;
    }
    
    /** Accessor to get edge length.
     * 
     * @return edge length.
     */
    public double getEdgeLength() {
        return edgeLength;
    }
    /** Modifier for edge length. 
     * 
     * @param edgeLength *new radius*
     */
    public void setEdgeLength(double edgeLength) {
        this.edgeLength = edgeLength;
    }
    
    /**  Returns a String representation of the cube's edge length
     * and X,Y,Z coordinates. 
     * 
     * @return x,y,z coordinates and edgelength. 
     * 
     */
    public String toString() {
        String result = "X-coordinate: " + valueX + "\nY-coordinate: " 
                + valueY + "\nZ-coordinate: " + valueZ + "\nEdge Length: " 
                + this.edgeLength;
        return result;
    }
    /** Surface area calculation. 
     * 
     * @return surface area. 
     */
    public double getSurfaceArea() {
        return (SIX * Math.pow(edgeLength, 2));
    }
    /** Volume calculation. 
     * 
     * @return volume.
     */
    public double getVolume() {
        return (Math.pow(edgeLength, THREE));
    }
    /** Face diagonal calculation. 
     * 
     * @return face diagonal.
     */
    public double getFaceDiagonal() {
        return (Math.sqrt(2) * edgeLength);
    }
    /** Space diagonal calculation. 
     * 
     * @return space diagonal.
     */
    public double getSpaceDiagonal() {
        return (Math.sqrt(THREE) * edgeLength);
    }
}
