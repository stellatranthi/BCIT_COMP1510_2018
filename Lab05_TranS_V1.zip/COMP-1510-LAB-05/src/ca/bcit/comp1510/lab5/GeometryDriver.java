package ca.bcit.comp1510.lab5;

import java.util.Scanner;
import java.text.DecimalFormat;

/**
 * To three decimal places, surface area, volume, slant height, and
 * two diagonals of various shapes. 
 * 
 * @author stella
 * @version 1
 */

public class GeometryDriver {
    /**Drives the program.
     * 
     * @param args unused
     */
    public static void main(String[] args) {
        DecimalFormat fmt = new DecimalFormat("#.###");
        Scanner scan = new Scanner(System.in);
        
        
        sphereTesting(scan, fmt);
        cubeTesting(scan, fmt);
        coneTesting(scan, fmt);   
        scan.close();
    }
    
    public static void sphereTesting(Scanner scan, DecimalFormat fmt){
        
        System.out.println("Please enter the sphere's radius, x-coordinate, "
                + "y-coordinate, and z-coordinate: \n*Values must be in that "
                + "exact order and separated by a single space");
        double sphereRadius = Double.parseDouble(scan.next());
        double sphereValueX = Double.parseDouble(scan.next());
        double sphereValueY = Double.parseDouble(scan.next());
        double sphereValueZ = Double.parseDouble(scan.next());
        
        final Sphere sphere = new Sphere(sphereRadius, sphereValueX, 
                sphereValueY, sphereValueZ);
        System.out.println("Sphere's surface: " 
            + fmt.format(sphere.getSurfaceArea()) + "\nSphere's volume: " 
            + fmt.format(sphere.getVolume()));     

    }
    
    public static void cubeTesting(Scanner scan, DecimalFormat fmt) {
        System.out.println("\nPlease enter the cube's x-coordinate, y-coordinate,"
                + " z-coordinate, and edge length: \n  *Values must be in"
                + " that exact order and separated by a single space");
        
        double cubeValueX = Double.parseDouble(scan.next());
        double cubeValueY = Double.parseDouble(scan.next());
        double cubeValueZ = Double.parseDouble(scan.next());
        double cubeEdgeLength = Double.parseDouble(scan.next());
        
        final Cube cube = new Cube(cubeValueX, cubeValueY, cubeValueZ, 
                cubeEdgeLength);
        
        
        System.out.println("Cube's x-coordinate: " + cube.getValueX() 
                + "\nCube's y-coordinate: " + cube.getValueY()
                + "\nCube's z-coordinate: " + cube.getValueZ()
                + "\nCube's edge length: " + cube.getEdgeLength()
                + "\nCube's surface area: " 
                + fmt.format(cube.getSurfaceArea()) + "\nCube's volume: " 
                + fmt.format(cube.getVolume()) + "\nCube's face diagonal: " 
                + fmt.format(cube.getFaceDiagonal()) 
                + "\nCube's space diagonal: " 
                + fmt.format(cube.getSpaceDiagonal()));
     }
    public static void coneTesting(Scanner scan, DecimalFormat fmt) {
        
        System.out.println("\nPlease enter the cone's radius" 
                + " and height: \n *Values must be in that exact order"
                + " and separated by a single space");
    
        double coneRadius = Double.parseDouble(scan.next());
        double coneHeight = Double.parseDouble(scan.next());
    
        final Cone cone = new Cone(coneRadius, coneHeight);
        System.out.println("Cone's radius: " + cone.getRadius() 
            + "\nCone's height: " + cone.getHeight() 
            + "\nCone's volume: " + fmt.format(cone.getVolume())
            + "\nCone's slant height: " 
            + fmt.format(cone.getSlantHeight()) 
            + "\nCone's surface area: " 
            + fmt.format(cone.getSurfaceArea()));
        
    }
}
