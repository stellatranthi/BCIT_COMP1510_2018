package ca.bcit.comp1510.lab1;
/**
 * Used for learning about string concatenation and arithmetic 
 * 
 * @author stella
 * @version 2018
 */
public class Birds {
/** 
 * Practicing string concatenation and arithmetic
 * @param args unused 
 */
	public static void main(String[] args) {
		System.out.println("Ten robins plus 13 canaries is "+(13+10)+" birds");
	}
}
