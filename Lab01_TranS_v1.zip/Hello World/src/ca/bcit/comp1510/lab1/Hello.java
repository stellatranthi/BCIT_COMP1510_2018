package ca.bcit.comp1510.lab1;

/**
 * Hi
 * 
 * @author stell
 * @version 2018
 */
public class Hello {

	/**
	 * Prints the greeting.
	 * 
	 * @param args
	 *      unused
	 */
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
}
