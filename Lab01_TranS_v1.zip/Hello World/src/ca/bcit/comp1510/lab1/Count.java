// Counting to 5 in 3 different languages
package ca.bcit.comp1510.lab1;

/**
 * @author stell
 * @version 2018
 */
public class Count {

	/**
	 * Program prints out 1-5 in English, French, Spanish
	 */
	public static void main(String[] args) {
		
// prints out one to five in English //does this cause problems?
		System.out.println("one two three four give");
		
//prints out one to five in French
		System.out.println("un deux trois quatre cinq");

//prints out one to five in Spanish
		System.out.println("uno dos tres cuatro cinco");
		

	}

}
