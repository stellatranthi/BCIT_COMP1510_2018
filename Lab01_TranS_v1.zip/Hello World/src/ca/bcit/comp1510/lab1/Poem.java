/**
 * 
 */
package ca.bcit.comp1510.lab1;

/**
 * @author stell
 *
 */
public class Poem {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("\tRoses are red\n\tViolets are blue");
		System.out.println("\tSugar is sweet\n\tBut I have committment issues");
		System.out.println("\tSo I\'d rather just be friends\n\tAt this point in our relationship");
		
	}

}
