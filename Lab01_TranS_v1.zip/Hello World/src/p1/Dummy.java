/**
 * 
 */
package p1;

/**
 * @author stell
 *
 */
public class Dummy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello World");

	}

}
