/**
 * 
 */
package ca.bcit.comp1510.lab4;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/** Creates a circle with 'Stella Tran' in it.
 * @author stella
 * @version 1
 */
public class MyFirstGraphicProgram extends Application {
    /** X and Y value for background in pixels is 500.
     * BGROUND stands for background.
     */
    public static final int BGROUND = 500;
    /**Radius for circle in pixels is 100.
     * CRADIUS stands for circle radius.
     */
    public static final int CRADIUS = 100;
    /** X AND Y value for shape to be in center of scene.
     * 
     */
    public static final int LOCATION = 250;
    /** X AND Y value for text to be in center of scene.
     * NAMEL stands for name location.
     */
    public static final int NAMEL = 220;
   
    /* (non-Javadoc)
     * @see javafx.application.Application#start(javafx.stage.Stage)
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        Text name = new Text(NAMEL, LOCATION, "Stella Tran");
        name.setFill(Color.WHITE);
        
        Circle circle = new Circle(LOCATION, LOCATION, CRADIUS);
        circle.setFill(Color.GREEN);
        
        Group group1 = new Group(circle, name);
        
        Scene scene = new Scene(group1, BGROUND, BGROUND, Color.LIGHTBLUE);
        
        primaryStage.setTitle("Lab4");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**Launches the JavaFX application.
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);

    }

}
