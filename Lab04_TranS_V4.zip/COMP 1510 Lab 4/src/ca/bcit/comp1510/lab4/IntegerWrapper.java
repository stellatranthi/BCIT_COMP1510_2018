/**
 * 
 */
package ca.bcit.comp1510.lab4;

import java.util.Scanner;


/**Reads a user-inputted integer, and prints the binary, octal, and
 *  hexadecimal representation of said integer.
 * @author stella
 * @version 1
 */
public class IntegerWrapper {

    /** Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        System.out.println("Please enter an integer: ");
        Scanner scan = new Scanner(System.in);
        int userInput = scan.nextInt();
        // Used the integer class to convert decimal to binary
        String binary = Integer.toBinaryString(userInput);
        // Used the integer class to convert decimal to octal
        String octal = Integer.toOctalString(userInput);
        // Used the integer class to convert decimal to hexadecimal
        String hexadecimal = Integer.toHexString(userInput);
        
        System.out.println("Binary representation: " + binary 
                + "\nOctal representation: " + octal 
                + "\nHexadecimal representation: " + hexadecimal);
        
        System.out.println("\nThe range of possible Java integer:" 
                + Integer.MIN_VALUE + " to " + Integer.MAX_VALUE);
        
        System.out.println("\nPlease enter two integer values" 
                +  "(separate them by a single space): ");
        String integer1 = scan.next();
        String integer2 = scan.next();
        System.out.println("\nThe sum of the integers inputted are " 
                + (Integer.parseInt(integer1) 
                + Integer.parseInt(integer2)));
        scan.close();
    }

}
