/**
 * 
 */
package ca.bcit.comp1510.lab4;

/** Will be used to present a Name concept. 
 * @author stella
 * @version 1
 */
public class Name {
    /**
     * string represents the first name.
     */
    private String firstName;
    /**
     *  string represents the middle name.
     */
    private String middleName;
    /**
     * string represents the last name.
     */
    private String lastName;
    
    /** Constructor for class Name.
     * 
     * @param firstName unused
     * @param middleName unused
     * @param lastName unused
     */
    public Name(String firstName, String middleName, String lastName) {
       this.firstName = firstName;
       this.middleName = middleName;
       this.lastName = lastName;
    }
    
    /** method to get first name. 
     * 
     * @return to firstName description. 
     */
    public String getFirstName() {
        return firstName;
    }
    /**
     * Modifier for first name.  
     * @param firstName unused
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    /** Accessor to get middle name. 
     * 
     * @return middleName description.
     */
    public String getMiddleName() {
        return middleName;
    }
    
    /** Modifier for middle name.
     * 
     * @param middleName unused
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    /** Accessor to get last name. 
     * 
     * @return last name description.
     */
    public String getLastName() {
        return lastName;
    }
    
    /** Modifier for last name.
     * 
     * @param lastName unused
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /**
     * Returns a String representation of the full name.
     * @return toString description
     */
    public String toString() {
        String fullName = firstName + " " + middleName + " " + lastName;
        return fullName;
    }

}
