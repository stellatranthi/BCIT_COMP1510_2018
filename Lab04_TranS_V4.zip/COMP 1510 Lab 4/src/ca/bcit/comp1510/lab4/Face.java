/**
 * 
 */
package ca.bcit.comp1510.lab4;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.QuadCurve;
import javafx.scene.shape.Ellipse;

/** Using JavaFX to create a self-portrait.
 * @author stella
 * @version 1
 */
public class Face extends Application {

    /* (non-Javadoc)
     * @see javafx.application.Application#start(javafx.stage.Stage)
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        QuadCurve bangs = new QuadCurve();
        bangs.setStartX(150.0); 
        bangs.setStartY(230.0f); 
        bangs.setEndX(350.0f); 
        bangs.setEndY(220.0f); 
        bangs.setControlX(250.0f); 
        bangs.setControlY(80.0f);   
        bangs.setFill(Color.GREY);
        
        Rectangle hair = new Rectangle(172, 200, 160, 150);
        hair.setFill(Color.GREY);
        
        Circle face = new Circle(250, 250, 90);
        face.setFill(Color.WHITE);
        
        Circle eye1 = new Circle(210, 260, 10);
        eye1.setFill(Color.BLACK);
        
        Circle eye2 = new Circle(300, 260, 10);
        eye2.setFill(Color.BLACK);
        
        Circle nose = new Circle(270, 270, 4);
        eye2.setFill(Color.BLACK);
        
        Ellipse mouth = new Ellipse(250.0f, 300.0f, 20.0f, 10.0f);
        eye2.setFill(Color.BLACK);
        
        Group group1 = new Group(hair, face, bangs,  eye1, eye2, nose, mouth);
        
        Scene scene = new Scene(group1, 500, 500, Color.LIGHTBLUE);
        
        primaryStage.setTitle("Lab4: Face");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    /**
     * Launches the JavaFX application.
     * 
     * @param args
     *            command line arguments
     */
    public static void main(String[] args) {
        launch(args);

    }

}
