/**
 * 
 */
package ca.bcit.comp1510.lab4;

/** Class that contains methods for the student class.
 * Methods include getters and setters for year of birth, student
 * number, name and gpa.
 * @author stella
 * @version 1
 */
public class Student {
    /** Name of student. Format: first name, last name. */
    private String name;
    
    /** Student's year of birth.
     * 
     */
    private int yearOfBirth;
    
    /** Student's ID number.
     * 
     */
    private int studentNumber;
    
    /** Student's Grade Point Average aka GPA.
     * 
     */
    private double studentGPA;
    
    /**Constructor for class Student. 
     * 
     * @param name unused
     * @param yearOfBirth unused
     * @param studentNumber unused
     * @param studentGPA unused
     */
    public Student(String name, int yearOfBirth, int studentNumber, 
            double studentGPA) {
        this.name = name;
        this.yearOfBirth = yearOfBirth;
        this.studentNumber = studentNumber;
        this.studentGPA = studentGPA; 
    }
    /** Accessor for student's name.
     * 
     * @return student name description.
     */
    public String getName() {
        return name;
    }
    
    /** Modifier for student's name.
     * 
     * @param name unused.
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /** Accessor for student's year of birth.
     * 
     * @return year of birth description.
     */
    public int getdob() {
        return yearOfBirth;
    }
    /** Modifier for student's year of birth.
     * 
     * @param birthYear unused
     */
    public void setdob(int birthYear) {
        this.yearOfBirth = birthYear;
    }
    
    /** Accessor for student's ID number.
     * 
     * @return student's ID number description.
     */
    public int getStudentNumber() {
        return studentNumber;
    }
    /** Modifier for student's ID number.
     * 
     * @param studentNumber unused
     */
    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }
    
    /** Accessor for student's GPA.
     * 
     * @return student's GPA description.
     */
    public double getGPA() {
        return studentGPA;
    }
    /** Modifier for student's GPA.
     * 
     * @param gpa unused
     */
    public void setGPA(double gpa) {
        this.studentGPA = gpa;
    }
    
    /**Returns a String representation of Student.
     * @return studentInfo description.
     */
    public String toString() {
        String studentInfo = name + " " + yearOfBirth + " " + studentNumber + " " + studentGPA;
        return studentInfo;
    }
}
