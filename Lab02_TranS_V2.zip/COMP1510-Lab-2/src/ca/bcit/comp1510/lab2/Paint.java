package ca.bcit.comp1510.lab2;

import java.util.Scanner;
/**
 * 
 * Program used to determine how many cans of paint will be needed to paint a room
 * 
 * @author stell
 * @version 2018
 */
public class Paint {
	public static void main(String[] args) {
/**
 * 
 * The units of measurements will be litres and square feet.
 * 
 */
		final int COVERAGE = 400;
		double width;
		double length;
		double height; 
		double surfaceArea;
		int coats;
		double coverageNeeded; 
		double cansOfPaintNeeded; 
		
		Scanner scan = new Scanner(System.in); 
	
		System.out.print("Please enter the width of the room: ");
		width = scan.nextDouble(); 
		System.out.print("Please enter the length of the room: ");
		length = scan.nextDouble(); 
		System.out.print("Please enter the height of the room: ");
		height = scan.nextDouble(); 
		surfaceArea = (width*length)+2*(height*length)+(height*width);
		System.out.println("The total square footage that needs to be covered: "+surfaceArea);
		System.out.println("");
		
		System.out.print("Please enter your desired number of coats: ");
		coats = scan.nextInt(); 
		coverageNeeded = coats*surfaceArea;
		System.out.println("The new total square footage that needs to be covered: "+ coverageNeeded);
		cansOfPaintNeeded = coverageNeeded/COVERAGE;
		System.out.println("You will need to buy "+ cansOfPaintNeeded + " cans of paint");
		
		scan.close();
	}
}
