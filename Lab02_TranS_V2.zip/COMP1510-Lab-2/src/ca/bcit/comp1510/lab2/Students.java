package ca.bcit.comp1510.lab2;
/** 
 * Making a table to organize student points
 * 
 * @author stella
 * @version 2018
 */
public class Students {
	public static void main(String[] args) {
	System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	System.out.println("\t == Student Points==");
	System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////");
	System.out.println(" Name\t\t Lab\t Bonus\t Total\n ----\t\t ---\t -----\t -----");
	System.out.println(" Joe\t\t 43\t 7\t 50\n William\t 50\t 8\t 58");
	System.out.println(" Mary Sue\t 39\t 10\t 49\n Peng\t\t 87\t 6\t 93\n Kwon\t\t 99\t 0\t 99");
	
	}
}
