package ca.bcit.comp1510.lab2;

import java.util.Scanner;
/**
 * Circle class designed to calculate circumference and area of a circle
 * 
 * @author stella 
 * @version 2018
 * 
 */
public class Circle {
	/**
	 * Drives the program
	 * 
	 * @param args
	 *      unused
	 */
	public static void main(String[] args) {
		double PI=3.14159;
		double radius;
		double area;
		double circumference; 
		double doubleRadius;
		/**
		 * Now we'll be calculating the circumference and area with double the user-inputted radius
		 */
		double circumferencetrial;
		double areatrial;
		
		Scanner myScanner = new Scanner(System.in);
        
		System.out.print("Please enter circle's radius: ");
		radius = myScanner.nextDouble(); 
		doubleRadius = 2 * radius;
		
		circumference = 2 * radius * PI;
		area = radius * radius * PI; 
		
		myScanner.close(); 
		
		System.out.println("");
		System.out.println("The circumference of the circle: "+circumference);
		System.out.println("The area of the circle: "+area);
		
		circumferencetrial = 2 * doubleRadius * PI;
		areatrial = doubleRadius * doubleRadius * PI; 
		
		System.out.println("");
		System.out.println("If the radius was doubled,");
		System.out.println("");
		System.out.println("The circumference of the circle would be "+circumferencetrial);
		System.out.println("The area of the circle would be "+areatrial);
		
		/** 
		 * Using division to figure out how many times the area and circumference increased when the radius doubles
		 * 
		 */
		
		System.out.println("");
		System.out.println("Now if you were curious of the size difference,");
		System.out.println("The circumference increased by "+(circumferencetrial/circumference)+ " times");
		System.out.println("The area increased by "+(areatrial/area)+ " times");

		
	}
}
