/**
 * 
 */
package ca.bcit.comp1510.lab06;

/**Drives the Name class.
 * 
 * @author stella
 * @version 1
 */
public class NameDriver {
    /** THREE represents 3.
     * Will be used to test out NameDriver.
     */
    public static final int THREE = 3;
    
    /** TWENTY represents 20.
     * Will be used to test out NameDriver.
     */
    public static final int TWENTY = 20;
    
    /**Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        final Name myName = new Name("STELLA", "THI", "Tran");
        final Name trialName = new Name("SteLLa", "tHi", "tRAn");
        final Name trialTwoName = new Name("    ", "   ", "   ");
        
        trialName.setFirstName("     ");
        trialName.setMiddleName("     ");
        trialName.setLastName("     ");
        
        System.out.println("Length of name (without space): " 
                + myName.getFullLength());
        
        System.out.println("Initials: " + myName.getInitals());
        
        System.out.println("Character at user-inputted integer: " 
                + myName.getNthChar(THREE));
        
        System.out.println("Character at user-inputted integer" 
                + "(user-input exceeds length of name): "
                + myName.getNthChar(TWENTY));
        
        System.out.println("Last name first format: " 
                + myName.getLastNameFirst());
        
        System.out.println("User-input matches first name: " 
                + myName.equalsFirstName("Stella"));
        
        System.out.println("User-input matches full name: " 
                + myName.equalsName((trialName)));
        
        System.out.println("Full name printed: " + myName.toString());
        
        System.out.println("Full (trial one) name printed: " 
                + trialName.toString());
        
        System.out.println("Full name printed (name instantiated as white space): " 
                + trialTwoName.toString());
    }

}
