package ca.bcit.comp1510.lab06;

/**
 * 
 */
import java.util.Random;

/** Mathematics methods that will allow the JUnit tests 
 *  in the MathematicsTest class to pass. 
 * 
 * @author Stella
 * @version 1
 *
 */
public class Mathematics {
    
    /** Pi presents 3.14159.
     * Will be used in calculate area of a circle.
     * 
     */
    public static final double PI = 3.14159;
    
    /** Ratio of foot to kilomere is 0.0003048 to 1
     * Will be used to calculate how many kilometers 
     * there are from user-inputted feet value.
     * 
     */
    public static final double ONE_FOOT_TO_KILOMETRE_RATIO = 0.0003048;
    
    /** TEN represents 10.
     * TEN will be used in generating a random number.
     * 
     */
    public static final int TEN = 10;
    
    /** ELEVEN represents 11.
     * ELEVEN will be used in generating a random number.
     * 
     */
    public static final int ELEVEN = 11;
    
    /** FIFTEEN represents 15.
     * FIFTEEN will be used in generating a random number.
     * 
     */
    public static final int FIFTEEN = 15;
    
    /**
    * Returns the area of the circle with the specified radius.
    *
    * @param radius
    * of the circle.
    * @return area as a double
    */
    public double getCircleArea(double radius) {
        double circleArea = PI * Math.pow(radius, 2);
        return circleArea;
    }
    
    /** Returns the area of the square with the specified edge length.
     * @param edgeLength of the square.
     * 
     * @return area as a double
     */
    public double getSquareArea(double edgeLength) {
        double areaSquare = Math.pow(edgeLength, 2);
        return areaSquare;
    }
    
    /**
    * Returns the sum of the specified values.
    *
    * @param first
    * operand
    * @param second
    * operand
    * @return sum of the operands
    */
    public double add(double first, double second) {
        return first + second;
    }
    
    /**
    * Returns the product of the specified values.
    *
    * @param first
    * operand
    * @param second
    * operand
    * @return product of the operands
    */
    public double multiply(double first, double second) {
        return first * second;
    }
    
    /**
    * Returns the difference of the specified values.
    *
    * @param first
    * operand
    * @param second
    * operand
    * @return difference of the operands
    */
    public double subtract(double first, double second) {
        return first - second;
    }
    
    /**
    * Returns the quotient of the specified values. If the divisor is zero,
    * returns zero instead of NaN or infinity.
    *
    * @param first
    * operand
    * @param second
    * operand
    * @return quotient of the operands
    */
    public double divide(double first, double second) {
        double quotient = first / second;
        if (second == 0) {
            return 0;  
        } else {
            return quotient;
        }
    }
    
    /**
    * Returns the absolute value of the specified integer.
    *
    * @param number
    * to test
    * @return absolute value of number
    */
    public int absoluteValue(int number) {
        return Math.abs(number);
    }

    /**
    * Converts the specified number of feet to kilometres.
    * @param feet to convert
    * @return kilometres in the specified number of feet
    */
    public double convertFeetToKilometres(double feet) {
        return feet * ONE_FOOT_TO_KILOMETRE_RATIO;
    }

    /**
    * Returns the sum of the positive integers between 0 and the specified
    * number inclusive. If the specified number is negative, returns zero.
    *
    * @param number
    * upper bound
    * @return sum as an integer
    */
    public int sumOfInts(int number) {
        int sum = (number * (number + 1) / 2);
        if (number >= 1) {
            return sum;
        } else {
            return 0;
        }
    }

    /**
    * Returns true if the specified value is positive, else false.
    *
    * @param number
    * to test
    * @return true if number is positive, else false.
    */
    public boolean isPositive(int number) {
        if (number >= 1) {
            return true;
        }
        return false;
    }

    /**
    * Returns true if the specified value is even, else false.
    *
    * @param number
    * to test
    * @return true if number is even, else false.
    */
    public boolean isEven(int number) {
        int remainer = number % 2;
        if (remainer == 0) {
            return true;
        }
        return false;
    }
          
    /**
    * Returns sum of the even numbers between 0 and the specified value,
    * inclusive.
    * 
    * @param number
    *            upper bound
    * @return sum of the even numbers between 0 and number
    */
    public int sumOfEvens(int number) {
        int sum = 0;
        int count = 0;
        if (number == 0) {
            return 0;
        }
        if (number > 0) {
            while(count <= number) {
                sum += count;
                count += 2;
            }
        }  
        if (number < 0) {
            while (count >= number) {
                sum += count;
                count -= 2;
            }
        }
        return sum;

    }
    /**
    * Returns the sum of the numbers between zero and the
    * first parameter that are divisible by the second
    * number. For example, sumOfProducts(10, 3) will return
    * 3 + 6 + 9 = 18, and sumOfProducts(10, 2) will return
    * 2 + 4 + 6 + 8 + 10 = 30 and sumOfProducts(-10, 2) will
    * return -2 + -4 + -6 + -8 + -10 = -30.
    * @param bound the upper bound
    * @param divisor the divisor
    * @return sum
    */
    public int sumOfProducts(int bound, int divisor) {
        int sum = 0;
        int count = 0;
        if (bound == 0) {
            return 0;
        }
        if (bound > 0) {
            while (count <= bound) {
                sum += count;
                count += divisor;
            }
        }
        if (bound < 0) {
            while (count >= bound) {
                sum += count;
                count -= divisor;
            }
        }
        return sum;
    }
    
    /**
    * Returns a random number between 10 and 20 inclusive,
    * but NOT 15.
    * @return random number in range [10, 20] excluding 15.
    */
    public int getRandomNumberBetweenTenAndTwentyButNotFifteen() {
        Random gen = new Random();
        int randomNumber = gen.nextInt(ELEVEN) + TEN;
        while (randomNumber == FIFTEEN) {
            randomNumber = gen.nextInt(TEN) + TEN;
        }
        return randomNumber;
    }
}
