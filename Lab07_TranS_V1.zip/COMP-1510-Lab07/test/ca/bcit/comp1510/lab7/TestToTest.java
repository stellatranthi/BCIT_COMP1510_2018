package ca.bcit.comp1510.lab7;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

public class TestToTest {
    
    @Test
    public void testLargest1_2_3() {
        int max = ToTest.largest(1, 2, 3);
        assertEquals(3, max);
    }

    @Test
    public void testLargest2_3_1() {
        int max = ToTest.largest(1, 2, 3);
        assertEquals (3, max);
    }
    
    @Test
    public void testLargest3_2_1() {
        int max = ToTest.largest(3, 2, 1);
        assertEquals(3, max);
    }
    
    @Test
    public void testLargestList1_2_3() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        int max = ToTest.largest(arrayList);
        assertEquals(3, max);
    }
    
    @Test
    public void testLargestList2_3_1() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(1);
        int max = ToTest.largest(arrayList);
        assertEquals(3, max);
    }
    
    @Test
    public void testLargestList3_2_1() {
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        arrayList.add(3);
        arrayList.add(2);
        arrayList.add(1);
        int max = ToTest.largest(arrayList);
        assertEquals(3, max);
    }

}
