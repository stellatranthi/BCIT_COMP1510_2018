/** Lab 3 for COMP 1510
 * 
 */
package ca.bcit.comp1510.lab3;

import java.util.Random;
/**Simulate a random card generator.
 * @author stella
 * @version 1
 */
public class CardGame {

    /** Enumberated type that names all the cards in a deck.
     *
     */
    enum Rank { ace, two, three, four, five, six, 
        /**
         * Continuation of card values in the enumberated Rank.
         */
        seven, eight, nine, ten, jack, queen, king }

    /** Enumberated type that names all the standard card suites.
     * 
     */
    enum Suite { hearts, diamonds, clubs, spades }
    /** Drives the program.
    * @param args unused
    */
    public static void main(String[] args) {
        Random random = new Random(); 
        int randomRankChoice = random.nextInt(Rank.values().length);
        Rank randomRank = Rank.values()[randomRankChoice];
        int randomSuiteChoice = random.nextInt(Suite.values().length);
        Suite randomSuite = Suite.values()[randomSuiteChoice];
        System.out.println("Your randomly generated card is the " 
                + randomRank + " of " + randomSuite);
    }

}
