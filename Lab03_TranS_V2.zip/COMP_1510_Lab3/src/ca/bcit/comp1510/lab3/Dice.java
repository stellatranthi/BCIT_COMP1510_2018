package ca.bcit.comp1510.lab3;

import java.util.Random;

/**Program simulates the rolling of a collection of D&D dice.
 * @author stell
 * @version 1
 */
public class Dice {
    /**FOUR_SIDED_DIE IS SET TO 4 BECAUSE IT HAS 4 SIDES.
     *  
     */
    public static final int FOUR_SIDED_DIE = 4;

    /**SIX_SIDED_DIE IS SET TO 6 BECAUSE IT HAS 6 SIDES.
     *  
     */
    public static final int SIX_SIDED_DIE = 6;

    /**EIGHT_SIDED_DIE IS SET TO 8 BECAUSE IT HAS 8 SIDES.
     * 
     */
    public static final int EIGHT_SIDED_DIE = 8;

    /**TEN_SIDED_DIE IS SET TO 10 BECAUSE IT HAS 10 SIDES.
     * 
     */
    public static final int TEN_SIDED_DIE = 10;

    /**TWELVE_SIDED_DIE IS SET TO 12 BECAUSE IT HAS 12 SIDES.
     * 
     */
    public static final int TWELVE_SIDED_DIE = 12;
    
    /**TWENTY_SIDED_DIE IS SET TO 20 BECAUSE IT HAS 20 SIDES.
     * 
     */
    public static final int TWENTY_SIDED_DIE = 20;
    
    /**Drives the program.
    * @param args unused
    */
    public static void main(String[] args) {
    Random random = new Random();
    
   int fourSidedDie = random.nextInt(FOUR_SIDED_DIE) + 1;
   int sixSidedDie = random.nextInt(SIX_SIDED_DIE) + 1;
   int eightSidedDie = random.nextInt(EIGHT_SIDED_DIE) + 1;
   int tenSidedDie = random.nextInt(TEN_SIDED_DIE) + 1;
   int twelveSidedDie = random.nextInt(TWELVE_SIDED_DIE) + 1;
   int twentySidedDie = random.nextInt(TWENTY_SIDED_DIE) + 1;
   int sumOfDice = fourSidedDie + sixSidedDie + eightSidedDie 
        + tenSidedDie + twelveSidedDie + twentySidedDie;
   System.out.println("Your dice roll consists of: \n four-sided die: " 
        + fourSidedDie + "\n six-sided die: " + sixSidedDie 
        + " eight-sided die: " + eightSidedDie + "\n ten-sided-die: " 
        + tenSidedDie + "\n twelve-sided-die: " + twelveSidedDie 
        + " twenty-sided-die: " + twentySidedDie + "" 
        + "\n Sum of all the dice: " + sumOfDice);
    }

}
