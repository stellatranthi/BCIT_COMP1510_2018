/**
 * 
 */
package ca.bcit.comp1510.lab3;

import java.util.Scanner;
import java.text.DecimalFormat; 
/**Calculate the distance between two user-inputted values.
 * 
 * @author Stella
 * @version 1
 */
public class Distance {

    /**Drives the program.
     * @param args unused
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter your first coordinate value, " 
                + "and separate your values by a space: ");
        
        double x1 = scan.nextDouble();
        double y1 = scan.nextDouble();
        System.out.println("Please enter your second coordinate value, "
                + "and separate your values by a space: ");
        double x2 = scan.nextDouble();
        double y2 = scan.nextDouble();
        double valueX2MinusX1 = x2 - x1;
        double valueY2MinusY1 = y2 - y1;
        double valueXSquared = Math.pow(valueX2MinusX1, 2.0);
        double valueYSquared = Math.pow(valueY2MinusY1, 2.0);
        double result = Math.sqrt(valueXSquared + valueYSquared);
        System.out.println("The distance between your two coordinates is " 
                + result);
        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        System.out.println("The distance between your two coordinates is" 
                + "(to two decimal places)" + decimalFormat.format(result));
        scan.close();

    }

}
