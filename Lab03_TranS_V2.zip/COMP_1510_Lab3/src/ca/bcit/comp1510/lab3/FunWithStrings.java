/**Lab 3 for COMP1510.
 * 
 */
package ca.bcit.comp1510.lab3;

import java.util.Scanner;


/** FunWithStrings class will be experimentation with string functions.
 * @author Stella
 * @version 1
 */
public class FunWithStrings {

/**INDEX_3 presents 3 and will be used for substring index range.
 * 
 */
public static final int INDEX_3 = 3;

    /**Main method drives the program.
     * 
     * @param args unused
     */
     public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the title of your favourite book");
        String userInput = scan.nextLine();
        System.out.println(userInput);
        System.out.println("");
        
        System.out.println("What prints when userInput is called: " 
        + userInput);
        System.out.println("What prints when userInput.toUpperCase()" 
                + "is called: " + userInput.toUpperCase());
        System.out.println("");
        
        scan.close();
        System.out.println("The length of the title of the book is " 
                + userInput.length());
        String the = userInput.substring(0, INDEX_3);
        System.out.println("Does your title contain \'the\': " 
                + the.equalsIgnoreCase("The"));
        System.out.println("Book title in all caps: " 
                + userInput.toUpperCase());
        System.out.println("Book title in all lowercase: " 
                + userInput.toLowerCase());
        System.out.println("");
        
        String trimmedUI = userInput.trim();
        System.out.println("Printing string trimmedUserInput: " 
                + trimmedUI);
        String uIMiddle = trimmedUI.substring(1, (userInput.length() - 1));
        String userInputFirstLetter = trimmedUI.substring(0, 1);
        String uILastChar = trimmedUI.substring(userInput.length() - 1);
        System.out.println("Book title fully trimmed, in lower case," 
                + " with the first and last letters capitalized: " 
                + userInputFirstLetter.toUpperCase() + uIMiddle 
                + uILastChar.toUpperCase()); 
     }

}
