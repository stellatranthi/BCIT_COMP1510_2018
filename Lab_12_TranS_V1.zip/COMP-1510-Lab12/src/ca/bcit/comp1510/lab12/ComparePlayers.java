/**
 * 
 */
package ca.bcit.comp1510.lab12;

import java.util.Scanner;

/**Compares two players.
 * 
 * @author stella
 * @version 1
 *
 */
public class ComparePlayers {
    /** Jersey number four. */
    private static final int FOUR = 4;
    
    /** Jersey number six. */
    private static final int SIX = 6;
    
    /** Jersey number negative three. */
    private static final int NEG_THREE = -3;

    /**Drives the program.
     * @param args unused.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Player[] array = new Player[2];
        try {
            Player p1 = new Player(null, "Hawks", FOUR);
            System.out.println(p1.toString());
        } catch (NullPointerException npe) {
            System.out.println("Name cannot be null "
                    + "or composed of whitespace.");
            
        }
        
        try {
            Player p2 = new Player("Phill", "  ", SIX);
            System.out.println(p2.toString());
        } catch (IllegalArgumentException iae) {
            System.out.println(iae.getMessage());
        }
        
        try {
            Player p3 = new Player("Kim", "Eagles", NEG_THREE);
            System.out.println(p3.toString());
        } catch (IllegalArgumentException iae) {
            System.out.println(iae.getMessage());
        }
        
        for (int i = 0; i < array.length; i++) {
            try {
             System.out.println("Enter player name: ");
             String name = scan.nextLine();
             System.out.println("Enter team name: ");
             String teamName = scan.nextLine();
             System.out.println("Enter jersey number: ");
             int number = Integer.parseInt(scan.nextLine());
             array[i] = new Player(name, teamName, number);
            } catch (IllegalArgumentException iae) {
                System.out.println(iae.getMessage());
            }
         }
        
        System.out.println(array[0].compareTo(array[1]));
        System.out.println(array[0].equals(array[1]));
        
        scan.close();
    }        
}
