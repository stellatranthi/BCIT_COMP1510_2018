package ca.bcit.comp1510.lab12;

/**Adds and multiples matrices (if possible).
 * 
 * @author stella
 * @version 1
 */
public class Matrix {
    /** 2D matrix. */
    private int[][] matrix;
    
    /**Constructor for matrix object.
     * 
     * @param rows *Number of rows*
     * @param columns *Number of columns*
     */
    public Matrix(int rows, int columns) {
        matrix = new int[rows][columns];
    }
    
    /**Returns the number of rows in matrix.
     * 
     * @return int.
     */
    public int getRows() {
        return matrix.length;
    }
    
    /**Returns the number of columns in the matrix.
     * 
     * @return int.
     */
    public int getColumns() {
        return matrix[0].length;
    }    
    
    /**<p>Accepts two integers for row and
     * column respectively and returns the int 
     * stored at that location in the matrix.</p>
     * 
     * @param row *Row*
     * @param col *Column*
     * @return int stored at that location.
     */
    public int getValue(int row, int col) {
        return matrix[row][col];
    }  
    
    /**New value placed into the
     *matrix at the specified row and column.
     * 
     * @param row *Row*
     * @param col *Column*
     * @param val *Value*
     */
    public void setValue(int row, int col, int val) {
        matrix[row][col] = val;
    }
    
    /**Prints the Matrix in matrix form.
     * 
     * @return String.
     */
    public String toString() {
        String result = "";
        for (int row = 0; row < matrix.length; row++) {
            result += "| ";
            for (int col = 0; col < matrix[row].length; col++) {
                result += matrix[row][col] + " ";
            }
            result += "|\n";
        }
        return result;
    }
    
    /**Adds matrixes.
     * 
     * @param matrix2 *Matrix in parameter.*
     * @return matrix3.
     */
    public Matrix add(Matrix matrix2) {
        if (this.getRows() == matrix2.getRows() 
                && this.getColumns() == matrix2.getColumns()) {
            Matrix matrix3 = new Matrix(this.getRows(), this.getColumns());
            for (int r = 0; r < this.getRows(); r++) {
                for (int c = 0; c < this.getColumns(); c++) {
                    int sum = this.getValue(r, c) + matrix2.getValue(r, c);
                    matrix3.setValue(r, c, sum);
                }
            }
            return matrix3;    
        } else {
           throw new IllegalArgumentException("Addition is not possible "
                   + "due to the matrixes' differing dimensions.");
        }
    }
    
    /**Multiplies matrixes.
     * 
     * @param matrix2 *Matrix in parameter*
     * @return matrix3
     */
    public Matrix multiply(Matrix matrix2) {
        if (this.getColumns() == matrix2.getRows()) {
            Matrix matrix3 = new Matrix(this.getRows(), matrix2.getColumns());
            for (int r = 0; r < this.getRows(); r++) {
                int sum = 0;
                for (int c = 0; c < matrix2.getColumns(); c++) {
                    for (int i = 0; i < this.getColumns(); i++) {
                        sum += this.getValue(r, i) 
                                * matrix2.getValue(i, c);
                    }
                    matrix3.setValue(r, c, sum);
                    sum = 0;
                }
            }
            return matrix3;
        } else {
            throw new IllegalArgumentException("Multiplican is not possible. "
                    + "The number of columns of the first matrix \ndoes "
                    + "not equal the number of rows of the second matrix");
        }
    }
}
