/**
 * 
 */
package ca.bcit.comp1510.lab12;

/**Drives the Matrix class.
 * 
 * @author stella
 * @version 1
 */
public class MatrixDriver {
    /** Matrix size of two. */
    private static final int TWO = 2;
    
    /** Matrix value 3. */
    private static final int THREE = 3;
    
    /** Matrix value 4. */
    private static final int FOUR = 4;
    
    /** Matrix value 5. */
    private static final int FIVE = 5;

    /** Matrix value 6. */
    private static final int SIX = 6;
    /**Drives the program.
     * @param args unused.
     */
    public static void main(String[] args) {
        Matrix matrix1 = new Matrix(TWO, TWO);
        matrix1.setValue(0, 0, TWO);
        matrix1.setValue(0, 1, THREE);
        matrix1.setValue(1, 0, FOUR);
        matrix1.setValue(1, 1, FIVE);
        
        Matrix matrix2 = new Matrix(TWO, TWO);
        matrix2.setValue(0, 0, 1);
        matrix2.setValue(0, 1, TWO);
        matrix2.setValue(1, 0, THREE);
        matrix2.setValue(1, 1, FOUR);
        System.out.println("Matrix 1: \n" + matrix1.toString());
        System.out.println("Matrix 2: \n" + matrix2.toString());
        
        System.out.println("Result Matrix: \n(matrix1 + matrix2)\n" 
                + matrix1.add(matrix2).toString());

        Matrix matrix3 = new Matrix(TWO, THREE);
        matrix3.setValue(0, 0, 1);
        matrix3.setValue(0, 1, TWO);
        matrix3.setValue(0, 2, THREE);
        matrix3.setValue(1, 0, FOUR);
        matrix3.setValue(1, 1, FIVE);
        matrix3.setValue(1, 2, SIX);
        System.out.println("Matrix 3: \n" + matrix3.toString());
        
        try {
            System.out.println(matrix1.add(matrix3).toString());
        } catch (IllegalArgumentException iae) {
            System.out.println("Is addition between matrix3 "
                    + "and matrix1 possible?");
            System.out.println(iae.getMessage());
            //throw new IllegalArgumentException();
        }
        
        System.out.println("\nResult Matrix: \n(matrix2 * matrix3)\n"
                + matrix2.multiply(matrix3).toString());
        
        try {
            System.out.println(matrix3.multiply(matrix2).toString());
        } catch (IllegalArgumentException iae) {
            System.out.println("Is matrix3 multiplied by matrix2 possible?");
            System.out.println(iae.getMessage());
            //throw new IllegalArgumentException();
        }
    }

}
