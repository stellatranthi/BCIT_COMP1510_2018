/**
 * 
 */
package ca.bcit.comp1510.lab12;

/**Represents a player object.
 * 
 * @author stella
 * @version 1
 *
 */
public class Player implements Comparable<Player> {
    
    /** Name of player. */
    private final String playerName;
    
    /** Player's team name. */
    private final String teamName;
    
    /** Player's jersey number. */
    private final int jersey;
    
    /**Constructor for Player object consist of player name,
     * team name, and jersey number.
     *     
     * @param name *Cannot be null or be composed of whitespace*
     * if invalid throws an IllegalArgumentException.
     * @param team *Cannot be null or be composed of whitespace*
     * if invalid throws an IllegalArgumentException.
     * @param number *Cannot be zero or a negative number.
     * if invalid throws an IllegalArgumentException.
     */
    public Player(String name, String team, int number) {
        if (name.trim().length() == 0 | name == null) {
            throw new IllegalArgumentException("Name cannot be null "
                    + "or composed of whitespace.");
        } else {
            this.playerName = name;
        }
        if (team.trim().length() == 0 | team == null) {
            throw new IllegalArgumentException("Team name cannot be null "
                    + "or composed of whitespace.");
        } else {
            this.teamName = team;
        }
        if (number <= 0) {
            throw new IllegalArgumentException("Jersey number cannot be zero "
                    + "or a negative value.");
        } else {
            this.jersey = number;
        }
    }
    
    /**Returns player name.
     * 
     * @return playerName.
     */
    public String getPlayerName() {
        return playerName;
    }

    /**Returns team name.
     * 
     * @return teamName.
     */
    public String getTeamName() {
        return teamName;
    }

    /**Returns jersey number.
     * 
     * @return jerseryNumber.
     */
    public int getJersey() {
        return jersey;
    }
    

    @Override
    /**Places the player with the lowest jersey number first.
     * 
     * @param o (Second player)
     * @return int.
     */
    public int compareTo(Player o) {
        if (this.jersey <= o.getJersey()) {
            return -1;
         } else {
            return 1;
         }
    }
    
    /**Determines if object in parameter is equal to "this" object.
     * 
     * @param other *Other object*
     * @return true *if objects match, false otherwise*
     */
    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (this == other) {
            return true;
        }
        if (getClass() != (other.getClass())) {
            return false;
        }
        Player otherObj = (Player) other;
        if (playerName == null) {
            if (otherObj.playerName != null) {
                return false;
            }
        } else if (!playerName.equals(otherObj.playerName)) {
            return false;
        }
        if (jersey != otherObj.jersey) {
            return false;
        }
        if (teamName == null) {
            if (otherObj.teamName != null) {
                return false;
            }
        } else if (!teamName.equals(otherObj.teamName)) {
            return false;
        }
        return true;
    }

    /**Returns the player's name, team name, and jersey number 
     * in string form.
     * 
     * @return String.
     */
    public String toString() {
        return "Name: " + playerName + "\tTeam Name: " + teamName 
                + "\tJersey Number: " + jersey;
    }

}
