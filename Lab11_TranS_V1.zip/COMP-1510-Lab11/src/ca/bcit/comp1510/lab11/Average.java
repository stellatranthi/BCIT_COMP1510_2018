/**
 * 
 */
package ca.bcit.comp1510.lab11;

/**Prints Strings passed to the program via command line.
 * 
 * @author stella
 * @version 1
 */
public class Average {

    /**Drives the program.
     * 
     * @param args unused.
     */
    public static void main(String[] args) {
        int sum = 0;
        int i = 0;
        boolean crash = false;
       if (args.length == 0 | args == null) {
           System.out.println("No arguments");
       } else {
           try {
               for (i = 0; i < args.length; i++) {
                   sum += Integer.parseInt(args[i]);
               }
               
           } catch (IllegalArgumentException iae) {
               System.out.println(args[i] + " is not an integer");
               crash = true;
           }

           System.out.println("Average is " 
                   + (sum / (crash ? args.length - 1 : args.length)));
       }

    }

}
