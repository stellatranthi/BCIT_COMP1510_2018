package ca.bcit.comp1510.lab11;

/**<p>Used to instantiate objects whose regular
 *methods are protected. If the object is locked, 
 *the methods cannot be invoked. If the object is 
 *unlocked, the methods can be invoked. </p>
 * 
 * @author stella
 * @version 1
 */
public interface Lockable {
    
    /**Establishes the key used to unlock.
     * 
     * @param key *to unlock object's methods*
     */
    void setKey(int key);

    /**unlocks the implementing object if the correct key is
     *provided and returns true if the object was unlocked.
     * 
     * @param key *to unlock object's methods*
     * @return true if the object was unlocked.
     */
    boolean unlock(int key);
    
    /**returns true if the implementing object is locked.
     * 
     * 
     * @return true if object is locked.
     */
    boolean locked();
}
