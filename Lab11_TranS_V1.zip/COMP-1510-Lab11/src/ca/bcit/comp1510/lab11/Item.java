package ca.bcit.comp1510.lab11;
/**Simulates part of a point of sale (cash register) system.
 * 
 * @author stella
 * @version 1
 */
public class Item {
    /** Name of the item.*/
    private final String name;
    
    /**Price of the item. */
    private final double price;
    
    /** Quantity of item being purchased. */
    private final int quantity;
    
    /**Constructor for object item.
     * 
     * @param itemName *Name of the item*
     * @param itemPrice *Price of the item*
     * @param itemQuantity *Item quantity*
     */
    public Item(String itemName, double itemPrice, int itemQuantity) {
        this.name = itemName;
        this.price = itemPrice;
        this.quantity = itemQuantity;
    }
    
    /**Constructor for object item.
     * 
     * @param itemName *Name of the item*
     * @param itemPrice *Price of the item*
     */
    public Item(String itemName, double itemPrice) {
        this.name = itemName;
        this.price = itemPrice;
        this.quantity = 1;
    }
    
    /**Accessor for item name.
     * 
     * @return name *item name*
     */
    public String getName() {
        return name;
    }
    
    /**Accessor for price of item.
     * 
     * @return price *price of item*
     */
    public double getPrice() {
        return price;
    }
    
    /**Accessor for quantity of item.
     * 
     * @return quantity *quantity of item*
     */
    public int getQuantity() {
        return quantity;
    }

}
