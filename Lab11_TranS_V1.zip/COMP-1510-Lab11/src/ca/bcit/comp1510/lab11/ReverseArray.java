/**
 * 
 */
package ca.bcit.comp1510.lab11;

import java.util.Scanner;

/**Reverses order in an array.
 * 
 * @author stella
 * @version 1
 */
public class ReverseArray {
    /** Max of ten integers per row. */
    static final int MAX = 10;
    
    /** Contains user input into an array. */
    private static int[] list;
    


    /**Drives the program.
     * @param args unused.
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("What is the limit of your array? (Integer)");
        int limit = scan.nextInt();
        list = new int[limit];
        for (int i = 0; i < limit; i++) {
            System.out.print("Enter a value for your array: ");
            int input = scan.nextInt();
            list[i] = input;
        }
        
        int count = 0;
        System.out.println("\nBefore sorting:");
        for (int value : list) {
            System.out.print(value + ", ");
            count++;
            if (count % MAX == 0) {
                System.out.println("");
            }
        }
        
        int start;
        int end = limit - 1;
        for (int i = 0; i < limit / 2; i++) {
            start = list[i];
            list[i] = list[end];
            list[end] = start;
            end--;    
        }
        
        int count2 = 0;
        System.out.println("\n\nAfter sorting:");
        for (int value : list) {
            System.out.print(value + ", ");
            count2++;
            if (count2 % MAX == 0) {
                System.out.println("");
            }
        }
        scan.close();  
        }
}
