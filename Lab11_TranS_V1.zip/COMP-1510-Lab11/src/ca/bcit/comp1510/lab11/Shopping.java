/**
 * 
 */
package ca.bcit.comp1510.lab11;

import java.util.Scanner;

/**Driver class for item and transaction.
 * Simulates a shopping experience.
 * 
 * @author Stella
 * @version 1
 *
 */
public class Shopping {
    /** Size of cart is ten. */
    private static final int TEN = 10;
    
    /** Customer transaction. */
    private static Transaction trans1;
    
    /** Single unit. */
    private static String single;
    
    /** Name of item. */
    private static String input;
    
    /**Are users getting more items. */
    private static String more;
    
    /** Price for a single unit. */
    private static double pricePerUnit;
    
    /**Drives the program.
     * @param args unused.
     */
    public static void main(String[] args) {
       Scanner scan = new Scanner(System.in);
       trans1 = new Transaction(TEN);
       shoppingTesting(scan);                          
       System.out.println(trans1.toString()); 
    }

    /**Simulates adding items to cart. 
     * 
     * @param scan *Scanner*
     */
    public static void shoppingTesting(Scanner scan) {
        System.out.println("Let's go shopping! Your cart size is 10");
        do {
            System.out.println("\nAdd something to the cart!");
            input = scan.next();
            System.out.println("What's the price per unit?");
            pricePerUnit = scan.nextDouble();
            System.out.println("Is it just one " + input 
                    + " today?\nType yes or no:");
            single = scan.next().trim().toUpperCase();
            switch (single) {
            case "YES":
                trans1.addToCart(input, pricePerUnit);
                break;
            case "NO":
                System.out.println("How many are you getting then?");
                int quan = scan.nextInt();
                trans1.addToCart(input, pricePerUnit, quan);
                break;
            default: 
                break;
            } 
            System.out.println("\nAre you getting more items?" 
                    + "\nType yes or no");
            more = scan.next();
        } while (more.equalsIgnoreCase("yes"));
    }
    
        
        
}   
