/**
 * 
 */
package ca.bcit.comp1510.lab11;

import java.lang.reflect.Array;
import java.text.NumberFormat;


/**Simulates a transaction.
 * 
 * @author stella
 * @version 1
 *
 */
public class Transaction {
    /** Cart size is increased by three. */
    static final int THREE = 3;
    
    /** Index of item in array. */
    private static int index;
    
    /** Item Array. */
    private Item[] cart;
    
    /**Represents the total price of the items in the array. */
    private double totalPrice;
    
    /**Represents the number of Item objects in the array. */
    private int itemCount;
    
    /** Limit of array. */
    private final int limit;
    
    /** Constructor for object Transaction.
     * 
     * @param limit *Size of array size*
     */
    public Transaction(int limit) {
        cart = new Item[limit];
        this.totalPrice = 0;
        this.itemCount = 0;
        this.limit = limit;
    }
    
    /**Adds item object to (array) cart.
     * 
     * @param itemName *Name of item*
     * @param itemPrice *Price of item*
     * @param itemQuantity *Quantity of item*
     */
    public void addToCart(String itemName, double itemPrice, int itemQuantity) {
        if (itemQuantity >= cart.length) {
            increaseSize();
        }
        Item item = new Item(itemName, itemPrice, itemQuantity);
        for (int i = 0; i < itemQuantity; i++) {
            cart[index] = item;
            itemCount += 1;  
            index++;
            totalPrice += itemPrice;
        }    
    }
    
    /**Adds an item object to (array) cart.
     * 
     * @param name *Item name*
     * @param itemPrice *Unit price of item*
     */
    public void addToCart(String name, double itemPrice) {
        Item item = new Item(name, itemPrice);
        if ((index + 1) > limit) {
            increaseSize();
        }
        cart[index] = item;
        Array.get(cart, index);
        index++; 
        totalPrice += (itemPrice);
        itemCount += 1;
    }
    
    /**Increases the size of cart. */
    public void increaseSize() {
        Item[] temp = new Item[cart.length + THREE];
        for (int i = 0; i < cart.length; i++) {
            temp[i] = cart[i];
        }
        cart = temp;
    }
    
    /**Returns the total price.
     * 
     * @return totalPrice *Total price*
     */
    public double getTotalPrice() {
        return totalPrice;
    }
    
    /**Returns the total number of items.
     * 
     * @return itemCount *Number of items*
     */
    public double getItemCount() {
        return itemCount;
    }
    
    /**Returns the total number of all items in the cart.
     * 
     * @return count *Number of all items in cart*
     */
    public int getCount() {
        int count = 0;
        for (int i = 0; i < cart.length; i++) {
            if (cart[i] != null) {
                count++;   
            }
        }
        return count;
    }

    /**
     * Returns a String representation of this transaction.
     * @return result *String of transaction*
     */
    public String toString() {
        NumberFormat fmt = NumberFormat.getCurrencyInstance();
        String result = "Receipt\n";
        for (Item item: cart) {
            if (item != null) {
                result += item.getName() + "\t" + fmt.format(item.getPrice()) 
                + "\t" + "1" + "\n";
            }
            
        }
        result += "The total price is: " + getTotalPrice();    
        return result;
    }
}
