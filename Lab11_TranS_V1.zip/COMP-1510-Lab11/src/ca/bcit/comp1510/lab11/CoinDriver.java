/**
 * 
 */
package ca.bcit.comp1510.lab11;

/**Driver for the coin class.
 * 
 * @author stella
 * @version 1
 *
 */
public class CoinDriver {
    /** Value for key is four.*/
    static final int KEY = 4;

    /**Drives the program.
     * @param args unused.
     */
    public static void main(String[] args) {
        System.out.println("Creating a coin object and flipping it.");
        Coin coin = new Coin();
        coin.flip();
        System.out.println("Is flip heads? " + coin.isHeads());
        System.out.println("");
        
        System.out.println("Setting the key and flipping coin.");
        coin.setKey(KEY);
        System.out.println("Is coin locked? " + coin.locked());
        coin.flip();
        
        System.out.println("\nUnlocking and flipping coin.");
        coin.unlock(KEY);
        coin.flip();
        System.out.println("Is flip heads? " + coin.isHeads());
    }

}
