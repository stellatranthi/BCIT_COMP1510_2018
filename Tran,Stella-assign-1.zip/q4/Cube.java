package q4;

import java.util.Scanner;

/**
 * With a user-submitted number that represents a cube's length,
 * The program will calculate the cube's volume and surface area. 
 * 
 * 
 * 
 *
 * @author Stella
 * @version 1.0
 */
public class Cube {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        System.out.println("Please enter the length of the cube's side");
        Scanner scan = new Scanner(System.in);
        
        double lengthofcube = scan.nextDouble();
        final double volumeFormula = 3;
        final double surfaceAreaForumla = 6;
        
        double volume = lengthofcube * volumeFormula;
        double surfacearea = lengthofcube * surfaceAreaForumla;
        
        System.out.println("The volume of the cube is " + volume);
        System.out.println("The surface area of the cube is " + surfacearea);
        
        scan.close();
        System.out.println("Question four was called and ran sucessfully.");
    }

};
