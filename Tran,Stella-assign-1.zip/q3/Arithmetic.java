package q3;

import java.util.Scanner;

/** Reads two floating point numbers and prints their sum, difference, 
 * quotient, and product.
 *
 * @author Stella
 * @version 1.0
 */
public class Arithmetic {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        System.out.println("Please enter your first floating number:");
        Scanner scan = new Scanner(System.in);
        double floatingPointNumber1 = scan.nextDouble();

        System.out.println("Please enter your first floating number:");
        double floatingPointNumber2 = scan.nextDouble();
        scan.close();
        
        double sum = floatingPointNumber1 + floatingPointNumber2;
        double difference = floatingPointNumber1 - floatingPointNumber2;
        double quotient = floatingPointNumber1 / floatingPointNumber2;
        double product = floatingPointNumber1 * floatingPointNumber2;

        System.out.println("The sum of the two numbers submitted is: " 
                + sum);
        System.out.println("The difference of the two numbers submitted is: " 
                + difference);
        System.out.println("The quotient of the two numbers submitted is: " 
                + quotient);
        System.out.println("The product of the two numbers submitted is: " 
                + product);
        System.out.println("Question three was called and ran sucessfully.");
    }

};
