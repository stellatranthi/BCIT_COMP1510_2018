package q5;

import java.util.Scanner;
/**
 * Encodes a 5 MIX-character string into a single int variable and
 * decode an int value back into MIX-characters.
 *
 * @author Stella
 * @version 1.0
 */
public class Pack {
    /**Index_0 represents 0.
     * 
     */
    public static final int INDEX_0 = 0;
     /*** Index_1 represents 1.
      *
      */
    public static final int INDEX_1 = 1;
    /**Index_2 represents 2.
     * 
     */
    public static final int INDEX_2 = 2;
    /**Index_3 represents 3. 
     * 
     */
    public static final int INDEX_3 = 3;
    /**Index_4 represents 4.
     * 
     */
    public static final int INDEX_4 = 4;

     /**Creating constant of 56 to later aid in conversion.
      * 
      */
    public static final int BASE_56 = 56; 
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        System.out.println("Please enter five characters [A-I]");
        Scanner scan = new Scanner(System.in);
        
        String userInput = scan.nextLine();
        
        char c0 = userInput.charAt(INDEX_0);    
        char c1 = userInput.charAt(INDEX_1);
        char c2 = userInput.charAt(INDEX_2);
        char c3 = userInput.charAt(INDEX_3);
        char c4 = userInput.charAt(INDEX_4);
        
        int value0 = c0 - 'A' + 1;
        int value1 = c1 - 'A' + 1;
        int value2 = c2 - 'A' + 1;
        int value3 = c3 - 'A' + 1;
        int value4 = c4 - 'A' + 1;
        
        int encoded = value0;
        value0 = encoded % BASE_56;
        
        encoded = encoded * BASE_56 + value1;
        value1 = encoded % BASE_56;
        
        encoded = encoded * BASE_56 + value2;
        value2 = encoded % BASE_56;
        
        encoded = encoded * BASE_56 + value3; 
        value3 = encoded % BASE_56;
        
        encoded = encoded * BASE_56 + value4;
        value4 = encoded % BASE_56;
        
        c4 = (char) ((value0 % BASE_56) + 'A' - 1);
        c3 = (char) ((value1 % BASE_56) + 'A' - 1);
        c2 = (char) ((value2 % BASE_56) + 'A' - 1);
        c1 = (char) ((value3 % BASE_56) + 'A' - 1);
        c0 = (char) ((value4 % BASE_56) + 'A' - 1);
        System.out.println("Encoded: " + encoded + "\nDecoded: " 
                + c4 + c3 + c2 + c1 + c0);
        scan.close();
    }

};
