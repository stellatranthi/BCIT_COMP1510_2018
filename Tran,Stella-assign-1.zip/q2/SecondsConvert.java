package q2;

import java.util.Scanner;

/**
 * Converts seconds into hours, minutes and seconds in the format
 * hh:mm:ss according to the number submitted by user (in seconds).
 *
 * @author Stella
 * @version 1.0
 */
public class SecondsConvert {
    /**
     * This is the entry point that gets called to run the program.
     *
     * @param args unused.
     */

     /**Converting seconds into hours.
     * 
     */
    public static final double TO_CONVERT_HOURS = 3600; 

    /**Converting seconds into minutes.
     * 
     */
    public static final double TO_CONVERT_MINUTES = 60; 
    
    /**This is the entry point that gets called to run the program.
    *
    * @param args unused.
    */  
    public static void main(String[] args) {

        System.out.println("Please enter an integer value to be converted: ");
        Scanner scan = new Scanner(System.in);

        double inputtedNum = scan.nextDouble();
        int hours = (int) (inputtedNum / TO_CONVERT_HOURS); 
        int minutes = (int) (inputtedNum % TO_CONVERT_HOURS 
                / TO_CONVERT_MINUTES);
        int seconds = (int) (inputtedNum % TO_CONVERT_HOURS 
                % TO_CONVERT_MINUTES);

        System.out.println(hours + " : " + minutes + " : " + seconds);
        scan.close();
        System.out.println("Question two was called and ran sucessfully.");
    }

};
