package q1;

import java.util.Scanner;

/** Program's objective is to calculate the fewest number of each bill and 
 * coin needed to present a user-inputted amount.
 * 
 * @author Stella
 * @version 1.0
 */
public class Change {
    /** ROUND presents 0.0001 which will make sure the penny rounds up.
     * 
     */
    public static final double ROUND = 0.0001;
    /**Setting value of a ten dollar bill.
     * 
     */
    public static final double TEN_BILL = 10.00; 
    
    /**Setting value of a five dollar bill.
    *
    */
    public static final double FIVE_BILL = 5.00;
    
    /**Setting value of a toonie bill.
    *
    */
    public static final double TOONIE = 2.00;
    
    /**Setting value of a loonie bill.
    *
    */
    public static final double LOONIE = 1.00;
    
    /**Setting value of a quarter.
    *
    */
    public static final double QUARTER = 0.25;
    
    /**Setting value of a dime.
    *
    */
    public static final double DIME = 0.10;
    
    /**Setting value of a nickel.
    *
    */
    public static final double NICKEL = 0.05;

    /**Setting value of a penny.
     * 
     */
    public static final double PENNY = 0.01;
 
         /**This is the entry point that gets called to run the program.
         *
         * @param args unused.
         */  
        public static void main(String[] args) {
        
        System.out.println("Please enter the desired amount to be sorted: ");
        Scanner scan = new Scanner(System.in);
        
        double inputtedAmount = scan.nextDouble();
        inputtedAmount += ROUND;
        scan.close();
        
        int tenBills = (int) (inputtedAmount / TEN_BILL);
        double finalAnswer = inputtedAmount - (tenBills * TEN_BILL);
        
        int fiveBills = (int) (finalAnswer / FIVE_BILL);
        finalAnswer -= (FIVE_BILL * fiveBills);
        
        int toonies = (int) (finalAnswer / TOONIE);
        finalAnswer -= (toonies * TOONIE);

        int loonies = (int) (finalAnswer / LOONIE);
        finalAnswer -= (loonies * LOONIE);

        int quarters = (int) (finalAnswer / QUARTER);
        finalAnswer -= (quarters * QUARTER);
        
        int dimes = (int) (finalAnswer / DIME);
        finalAnswer -= (dimes * DIME);

        int nickels = (int) (finalAnswer / NICKEL);
        finalAnswer -= (nickels * NICKEL);

        int pennies = (int) (finalAnswer / PENNY);

        System.out.println("You'll have:\n" + tenBills + " ten dollar bills\n" 
                + fiveBills + " five dollar bills\n" + toonies + " toonies\n" 
                + loonies + " loonies\n" + quarters + " quarters\n" + dimes 
                + " dimes\n" + nickels + " nickels\n" + pennies + " pennies");
        
        System.out.println("Question one was called and ran sucessfully.");
    }

};
