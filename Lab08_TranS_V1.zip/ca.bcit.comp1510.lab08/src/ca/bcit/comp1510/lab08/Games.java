/**
 * 
 */
package ca.bcit.comp1510.lab08;

import java.util.Scanner;
import java.util.Random;

/** Making two games (guess a number and rock,paper, scissors). 
 * Game will keep track of score
 * 
 * @author stella
 *
 * @version 1
 */

public class Games {
    
    /** Keeps track of user's score.
     *  
     */
    private int userScore;
    
    
    /** Stores input value from user.
     *  
     */
    private int userInput;

    
    /**Constructor for class Games.
     * 
     */
    public Games() {
        this.userScore = 0;
    }
    
    /** Contains the function calls to play 'Guess a number'.
     * 
     */
    public void guessANumber() {
        Random gen = new Random();
        Scanner scan = new Scanner(System.in);
        System.out.println("I've picked a random number between 0 and 100\n"
                + "Can you guess it?\nGuess the number!");
        int num = gen.nextInt(100);
        int guess = scan.nextInt();
        while (!((guess >= 0) & (guess <= 100))) {
            System.out.println("That's not a valid guess! Try again!");
            guess = scan.nextInt();
        }
        int count = 1;
        boolean correct = false;
        while (correct == false) {
            if (guess == num) {
                if (count > 5) {
                    System.out.println("Took you too long!\nNo points awarded");
                    correct = true;
                } else {
                    System.out.println("Correct!\nFive Points "
                            + "have been awarded!");
                    userScore += 5;
                    correct = true;     
                }
            } else {
                if (guess < num) {
                    System.out.println("Too low, guess again!");
                    guess = scan.nextInt();
                    count++;
                } else {
                    System.out.println("Too high, guess again!");
                    guess = scan.nextInt();
                    count++;
                }
            }
        }
    }
    
    /** Contains the function calls to play 'Rock, paper scissors'.
     * 
     */
    public void rockPaperScissors() {
        Random gen = new Random();
        Scanner scan = new Scanner(System.in);
        System.out.println("I've pick one of ROCK, PAPER, and SCISSORS"
                + "\nWhich one do you choose?");
        int computer = gen.nextInt(3);
        String input = scan.nextLine();
        input = input.trim().toUpperCase();
        while (!input.equals("ROCK") && !input.equals("SCISSORS") 
                && !input.equals("PAPER")) {
            System.out.println("That's not a valid choice! Try again!");
            input = scan.nextLine().toUpperCase();
        }
        
        switch (input) {
        case "ROCK":
            if (computer == 0) {
                System.out.println("TIE! I chose ROCK too! No points awarded");
            } else if (computer == 1) {
                System.out.println("LOSS! I chose PAPER! You just lost "
                        + "3 points");
                userScore -= 3;
            } else if (computer == 2) {
                System.out.println("VICTORY! I chose SCISSORS! "
                        + "5 points have been awarded");
                userScore += 5;
            }
            break;
            
        case "PAPER":    
            if (computer == 1) {
                System.out.println("TIE! I chose PAPER too! No points awarded");
            } else if (computer == 2) {
                System.out.println("LOSS! I chose SCISSORS! "
                        + "You just lost 3 points");
                userScore -= 3;
            } else if (computer == 0) {
                System.out.println("VICTORY! I chose ROCK! "
                        + "5 points have been awarded");
                userScore += 5;
            }
            break;
            
        case "SCISSORS":    
            if (computer == 2) {
                System.out.println("TIE! I chose SCISSORS too! "
                        + "No points awarded");
            } else if (computer == 0) {
                System.out.println("LOSS! I chose ROCK! "
                        + "You just lost 3 points");
                userScore -= 3;
            } else if (computer == 1) {
                System.out.println("VICTORY! I chose PAPER! "
                        + "5 points have been awarded");
                userScore += 5;
            }
            break;
        }
    }
    
    
    /** Contains the function calls to make games accessible.
     * 
     */
    public void play() {
        Scanner scan = new Scanner(System.in);
        do {
            System.out.println("Welcome to the Games program!\n" 
                    + "Make your choice (enter a number):");
            System.out.println("1. See your score\r\n" 
                    + "2. Guess a number\r\n"
                    + "3. Play Rock, Paper, Scissors\r\n"
                    + "4. Quit");
            System.out.print("> ");
            userInput = scan.nextInt();
            String input = String.valueOf(userInput);
            while (!input.equals("1") && !input.equals("2") 
                    && !input.equals("3") && !input.equals("4")) {
                System.out.println("\nThat's not a valid choice!\n"
                        + "Please make another choice\n");
                userInput = scan.nextInt();
            }
            switch (input) {
                case "1":
                    System.out.println("Your score is " + userScore);
                    System.out.println("");
                    break;
                case "2":
                    guessANumber();
                    System.out.println("");
                    break;
                case "3":
                    rockPaperScissors();
                    System.out.println("");
                    break;
                case "4":
                    System.out.println("\nGoodbye for now!");
                    System.out.println("Your score is " + userScore);
                    scan.close();
                    break;
            }
        } while (!(userInput == 4));
    }

    /**
    * Drives the program.
    * @param args unused
    */
    public static void main(String[] args) {
    Games myGame = new Games();
    myGame.play();
    }
}
