/**
 * 
 */
package ca.bcit.comp1510.lab08;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Text;

/** Takes in two password values and confirms if they're matching.
 * @author Stella 
 * @version 1
 *
 */
public class PasswordValidator extends Application {
    /** Input for "Enter Password: ".
     * 
     */
    private TextField password = new TextField();
    
    /** Input for "Confirm Password: ".
     * 
     */
    private TextField confirmPassword = new TextField();

    /** Contains action event and text inputs.
     * 
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        final int appWidth = 500;
        final int appHeight = 240;
        Label enter = new Label("Enter Password:");
        enter.setTranslateX(70);
        enter.setTranslateY(50);
        
        Label confirm = new Label("Confirm Password:");
        confirm.setTranslateX(70);
        confirm.setTranslateY(110);
     
        password.setTranslateX(200);
        password.setTranslateY(50);
        
        confirmPassword.setTranslateX(200);
        confirmPassword.setTranslateY(105);
        
        Text validate = new Text();
        validate.setTranslateX(260);
        validate.setTranslateY(175);
        
        Button submit = new Button("Submit");
        submit.setTranslateX(70);
        submit.setTranslateY(160);
        
        submit.setOnAction((event) -> {
                String userInput = password.getText();
                String userInput2 = confirmPassword.getText();
                if (userInput.equals(userInput2)) {
                    validate.setText("VALID");
                } else {
                    validate.setText("INVALID");
                }
        });
                
        Group group = new Group(enter, password, confirm, 
                confirmPassword, submit, validate);
        
        Scene scene = new Scene(group, appWidth, appHeight, Color.LIGHTBLUE);
        
        primaryStage.setTitle("Password Validator");
        primaryStage.setScene(scene);
        primaryStage.show();
        

    }

    /** Drives the error.
     * @param args.
     */
    public static void main(String[] args) {
        launch(args);
    }

}
